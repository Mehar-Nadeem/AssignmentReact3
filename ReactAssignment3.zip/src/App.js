import logo from './logo.svg';
import './App.css';
import React from 'react'
import Students from './component/Students';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'

export default function App() {
  return (
    <div>
      <Students/>
    </div>
  )
}















