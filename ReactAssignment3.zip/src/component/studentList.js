import React from 'react'
import { Button, Modal } from 'react-bootstrap';
import { useState } from 'react';


export default function StudentList({ student, index, deleteHandler, updateHandler }) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (

    <tr>
      <td scope="col">{index}</td>
      <td scope="col">{student.firstName}</td>
      <td scope="col">{student.lastName}</td>
      <td scope="col">{student.emailId}</td>
      <td>
        <button className='btn btn-danger' onClick={() => deleteHandler(index)}>Delete</button>
      </td>
      <td>
        <button className='btn btn-info' onClick={() => updateHandler(student, index)}>update</button>
      </td>
      <td>

        <>
          <Button variant="primary" onClick={handleShow}>
            View
          </Button>

          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>StudentList</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <table className='table table-border text-center'>
             <tr>
                  <th>No.</th>
                  <th>FirstName</th>
                  <th>Last Name</th>
                  <th>E-mail</th>
                </tr>
                <tr>
                  <td scope="col">{index}</td>
                  <td scope="col">{student.firstName}</td>
                  <td scope="col">{student.lastName}</td>
                  <td scope="col">{student.emailId}</td>
                </tr>
              </table>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="primary" onClick={handleClose}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>
        </>
      </td>
    </tr>

  )
}
