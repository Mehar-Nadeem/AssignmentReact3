export const data=[
    {
        firstName:"Muhammad",
        lastName:"Nadeem",
        emailId:"muhammadnadeem9083@gmail.com"
    },
]